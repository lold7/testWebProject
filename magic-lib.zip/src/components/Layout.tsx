import { Outlet, Link } from 'react-router-dom';
import { ShoppingCart, User, Menu, Search, BookOpen } from 'lucide-react';

export default function Layout() {
  return (
    <div className="min-h-screen flex flex-col bg-bg-dark text-text-primary">
      {/* Header */}
      <header className="border-b-4 border-neon-green sticky top-0 z-50 bg-bg-dark/90 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button className="p-2 hover:text-neon-green transition-colors md:hidden">
              <Menu className="w-6 h-6" />
            </button>
            <Link to="/" className="flex items-center gap-2 group">
              <BookOpen className="w-8 h-8 text-neon-green group-hover:text-neon-cyan transition-colors" />
              <span className="pixel-text text-xl text-neon-green group-hover:text-neon-cyan transition-colors hidden sm:block">
                MAGIC LIB
              </span>
            </Link>
          </div>

          <div className="hidden md:flex items-center gap-8 pixel-text text-xs">
            <Link to="/quests" className="hover:text-neon-green transition-colors">QUESTS</Link>
            <Link to="/admin/inventory" className="hover:text-neon-pink transition-colors">ADMIN</Link>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 hover:text-neon-cyan transition-colors">
              <Search className="w-6 h-6" />
            </button>
            <Link to="/login" className="p-2 hover:text-neon-pink transition-colors">
              <User className="w-6 h-6" />
            </Link>
            <Link to="/cart" className="p-2 hover:text-neon-green transition-colors relative">
              <ShoppingCart className="w-6 h-6" />
              <span className="absolute top-0 right-0 bg-neon-pink text-bg-dark text-[10px] font-bold px-1.5 py-0.5 rounded-full pixel-text">
                3
              </span>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="border-t-4 border-neon-green bg-bg-panel mt-auto">
        <div className="max-w-7xl mx-auto px-4 py-8 md:py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <Link to="/" className="flex items-center gap-2 mb-4">
                <BookOpen className="w-8 h-8 text-neon-green" />
                <span className="pixel-text text-xl text-neon-green">MAGIC LIB</span>
              </Link>
              <p className="text-text-muted max-w-sm">
                Your portal to infinite worlds. Level up your mind with our curated collection of magical artifacts (books).
              </p>
            </div>
            
            <div>
              <h3 className="pixel-text text-sm text-neon-cyan mb-4">NAVIGATION</h3>
              <ul className="space-y-2 text-sm text-text-muted">
                <li><Link to="/" className="hover:text-neon-green">Home Base</Link></li>
                <li><Link to="/quests" className="hover:text-neon-green">Quest Board</Link></li>
                <li><Link to="/profile" className="hover:text-neon-green">Player Stats</Link></li>
                <li><Link to="/cart" className="hover:text-neon-green">Inventory</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="pixel-text text-sm text-neon-pink mb-4">SYSTEM</h3>
              <ul className="space-y-2 text-sm text-text-muted">
                <li><a href="#" className="hover:text-neon-pink">FAQ</a></li>
                <li><a href="#" className="hover:text-neon-pink">Support</a></li>
                <li><a href="#" className="hover:text-neon-pink">Terms of Service</a></li>
                <li><a href="#" className="hover:text-neon-pink">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t border-border-subtle flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="pixel-text text-[10px] text-text-muted">
              © {new Date().getFullYear()} MAGIC LIB. ALL RIGHTS RESERVED.
            </p>
            <div className="flex items-center gap-4 pixel-text text-[10px] text-text-muted">
              <span>INSERT COIN TO CONTINUE</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
