import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Filter, Search, Book, ChevronDown } from 'lucide-react';

export default function QuestLog() {
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b-2 border-neon-green pb-6">
        <div>
          <h1 className="pixel-text text-3xl md:text-4xl text-neon-green mb-2">QUEST LOG</h1>
          <p className="text-text-muted">Browse available artifacts and embark on your next adventure.</p>
        </div>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <input 
              type="text" 
              placeholder="SEARCH_QUESTS..." 
              className="w-full bg-bg-panel border-2 border-border-subtle pl-10 pr-4 py-2 font-mono text-sm focus:outline-none focus:border-neon-cyan text-text-primary"
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
          </div>
          <button 
            className="md:hidden p-2 border-2 border-border-subtle bg-bg-panel text-text-muted hover:text-neon-cyan hover:border-neon-cyan transition-colors"
            onClick={() => setIsFilterOpen(!isFilterOpen)}
          >
            <Filter className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar Filters */}
        <aside className={`w-full md:w-64 space-y-8 ${isFilterOpen ? 'block' : 'hidden md:block'}`}>
          <div className="space-y-4">
            <h3 className="pixel-text text-sm text-neon-cyan flex items-center justify-between border-b border-border-subtle pb-2">
              CLASS (GENRE) <ChevronDown className="w-4 h-4" />
            </h3>
            <ul className="space-y-2 font-mono text-sm">
              {['Cyberpunk', 'Sci-Fi', 'Fantasy', 'Horror', 'Mystery'].map((genre) => (
                <li key={genre}>
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <div className="w-4 h-4 border-2 border-border-subtle group-hover:border-neon-cyan flex items-center justify-center transition-colors">
                      {genre === 'Cyberpunk' && <div className="w-2 h-2 bg-neon-cyan" />}
                    </div>
                    <span className={`group-hover:text-neon-cyan transition-colors ${genre === 'Cyberpunk' ? 'text-neon-cyan' : 'text-text-muted'}`}>
                      {genre}
                    </span>
                  </label>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="pixel-text text-sm text-neon-pink flex items-center justify-between border-b border-border-subtle pb-2">
              DIFFICULTY <ChevronDown className="w-4 h-4" />
            </h3>
            <ul className="space-y-2 font-mono text-sm">
              {['Novice', 'Adept', 'Expert', 'Master'].map((diff) => (
                <li key={diff}>
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <div className="w-4 h-4 border-2 border-border-subtle group-hover:border-neon-pink flex items-center justify-center transition-colors" />
                    <span className="text-text-muted group-hover:text-neon-pink transition-colors">{diff}</span>
                  </label>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="pixel-text text-sm text-neon-yellow flex items-center justify-between border-b border-border-subtle pb-2">
              GOLD COST <ChevronDown className="w-4 h-4" />
            </h3>
            <div className="space-y-4">
              <input type="range" min="0" max="100" className="w-full accent-neon-yellow" />
              <div className="flex justify-between text-xs font-mono text-text-muted">
                <span>$0</span>
                <span>$100+</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Product Grid */}
        <div className="flex-1">
          <div className="flex justify-between items-center mb-6">
            <span className="text-sm text-text-muted font-mono">SHOWING 24 QUESTS</span>
            <select className="bg-bg-panel border border-border-subtle text-text-muted text-sm font-mono py-1 px-2 focus:outline-none focus:border-neon-green">
              <option>SORT: NEWEST</option>
              <option>SORT: PRICE (LOW TO HIGH)</option>
              <option>SORT: PRICE (HIGH TO LOW)</option>
              <option>SORT: RATING</option>
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { id: 1, title: "Ready Player One", author: "Ernest Cline", price: "15.99", img: "https://picsum.photos/seed/book1/400/600", tag: "NEW" },
              { id: 2, title: "Neuromancer", author: "William Gibson", price: "12.50", img: "https://picsum.photos/seed/book2/400/600", tag: "HOT" },
              { id: 3, title: "Snow Crash", author: "Neal Stephenson", price: "14.20", img: "https://picsum.photos/seed/book3/400/600" },
              { id: 4, title: "The Matrix Comics", author: "Wachowskis", price: "24.99", img: "https://picsum.photos/seed/book4/400/600" },
              { id: 5, title: "Do Androids Dream?", author: "Philip K. Dick", price: "11.99", img: "https://picsum.photos/seed/book5/400/600", tag: "SALE" },
              { id: 6, title: "Altered Carbon", author: "Richard K. Morgan", price: "16.50", img: "https://picsum.photos/seed/book6/400/600" },
              { id: 7, title: "I, Robot", author: "Isaac Asimov", price: "9.99", img: "https://picsum.photos/seed/book7/400/600" },
              { id: 8, title: "Dune", author: "Frank Herbert", price: "18.99", img: "https://picsum.photos/seed/book8/400/600", tag: "EPIC" },
              { id: 9, title: "Foundation", author: "Isaac Asimov", price: "14.50", img: "https://picsum.photos/seed/book9/400/600" },
            ].map((book) => (
              <Link key={book.id} to={`/product`} className="group flex flex-col gap-4 p-4 border-2 border-border-subtle hover:border-neon-green bg-bg-panel transition-colors rounded-lg relative overflow-hidden">
                <div className="aspect-[2/3] overflow-hidden rounded border border-border-subtle relative">
                  <img src={book.img} alt={book.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
                  {book.tag && (
                    <div className={`absolute top-2 right-2 bg-bg-dark/80 backdrop-blur px-2 py-1 rounded pixel-text text-[10px] border ${
                      book.tag === 'NEW' ? 'text-neon-cyan border-neon-cyan' :
                      book.tag === 'HOT' ? 'text-neon-pink border-neon-pink' :
                      book.tag === 'SALE' ? 'text-neon-yellow border-neon-yellow' :
                      'text-neon-green border-neon-green'
                    }`}>
                      {book.tag}
                    </div>
                  )}
                </div>
                <div className="space-y-2 flex-1 flex flex-col">
                  <h3 className="font-bold text-lg text-text-primary line-clamp-1 group-hover:text-neon-green transition-colors">{book.title}</h3>
                  <p className="text-sm text-text-muted">{book.author}</p>
                  <div className="mt-auto pt-4 flex items-center justify-between">
                    <span className="pixel-text text-sm text-neon-green">${book.price}</span>
                    <button className="p-2 bg-bg-dark border border-neon-green text-neon-green hover:bg-neon-green hover:text-bg-dark transition-colors rounded">
                      <Book className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {/* Pagination */}
          <div className="flex justify-center items-center gap-2 mt-12">
            <button className="w-10 h-10 flex items-center justify-center border-2 border-border-subtle text-text-muted hover:border-neon-green hover:text-neon-green transition-colors rounded">
              &lt;
            </button>
            <button className="w-10 h-10 flex items-center justify-center border-2 border-neon-green bg-neon-green/10 text-neon-green font-mono rounded">
              1
            </button>
            <button className="w-10 h-10 flex items-center justify-center border-2 border-border-subtle text-text-muted hover:border-neon-green hover:text-neon-green transition-colors font-mono rounded">
              2
            </button>
            <button className="w-10 h-10 flex items-center justify-center border-2 border-border-subtle text-text-muted hover:border-neon-green hover:text-neon-green transition-colors font-mono rounded">
              3
            </button>
            <span className="text-text-muted">...</span>
            <button className="w-10 h-10 flex items-center justify-center border-2 border-border-subtle text-text-muted hover:border-neon-green hover:text-neon-green transition-colors font-mono rounded">
              8
            </button>
            <button className="w-10 h-10 flex items-center justify-center border-2 border-border-subtle text-text-muted hover:border-neon-green hover:text-neon-green transition-colors rounded">
              &gt;
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
