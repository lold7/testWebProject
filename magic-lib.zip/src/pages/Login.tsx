import { Link } from 'react-router-dom';
import { User, Lock, ArrowRight, Github, Mail } from 'lucide-react';

export default function Login() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center py-12">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center space-y-4">
          <h1 className="pixel-text text-3xl md:text-4xl text-neon-pink mb-2 drop-shadow-[0_0_10px_rgba(255,0,255,0.5)]">
            PLAYER LOGIN
          </h1>
          <p className="text-text-muted font-mono text-sm">
            ENTER CREDENTIALS TO ACCESS YOUR INVENTORY
          </p>
        </div>

        <div className="bg-bg-panel border-4 border-neon-pink p-8 rounded-2xl relative overflow-hidden shadow-[0_0_30px_rgba(255,0,255,0.1)]">
          <div className="absolute top-0 right-0 w-32 h-32 bg-neon-pink/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2" />
          
          <form className="space-y-6 relative z-10">
            <div className="space-y-2">
              <label className="pixel-text text-[10px] text-neon-cyan flex items-center gap-2">
                <User className="w-4 h-4" /> USERNAME / EMAIL
              </label>
              <input 
                type="text" 
                placeholder="PLAYER_ONE..." 
                className="w-full bg-bg-dark border-2 border-border-subtle p-4 font-mono focus:outline-none focus:border-neon-cyan text-text-primary transition-colors"
                defaultValue="player_one@magiclib.com"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="pixel-text text-[10px] text-neon-cyan flex items-center gap-2">
                  <Lock className="w-4 h-4" /> PASSWORD
                </label>
                <a href="#" className="text-[10px] font-mono text-text-muted hover:text-neon-pink transition-colors">
                  FORGOT PASSWORD?
                </a>
              </div>
              <input 
                type="password" 
                placeholder="••••••••" 
                className="w-full bg-bg-dark border-2 border-border-subtle p-4 font-mono focus:outline-none focus:border-neon-cyan text-text-primary transition-colors"
                defaultValue="password123"
              />
            </div>

            <Link 
              to="/profile" 
              className="w-full pixel-border-pink bg-neon-pink text-bg-dark px-4 py-4 pixel-text text-sm hover:bg-bg-dark hover:text-neon-pink hover:pixel-border-cyan transition-all flex items-center justify-center gap-2 mt-8"
            >
              INSERT COIN TO START <ArrowRight className="w-4 h-4" />
            </Link>
          </form>

          <div className="mt-8 pt-8 border-t border-border-subtle relative z-10">
            <p className="text-center text-xs font-mono text-text-muted mb-4">OR CONNECT WITH</p>
            <div className="grid grid-cols-2 gap-4">
              <button className="flex items-center justify-center gap-2 bg-bg-dark border border-border-subtle p-3 rounded hover:border-neon-cyan hover:text-neon-cyan transition-colors text-sm font-mono text-text-muted">
                <Github className="w-4 h-4" /> GITHUB
              </button>
              <button className="flex items-center justify-center gap-2 bg-bg-dark border border-border-subtle p-3 rounded hover:border-neon-pink hover:text-neon-pink transition-colors text-sm font-mono text-text-muted">
                <Mail className="w-4 h-4" /> GOOGLE
              </button>
            </div>
          </div>
        </div>

        <div className="text-center">
          <p className="text-sm font-mono text-text-muted">
            NEW PLAYER? <a href="#" className="text-neon-cyan hover:text-neon-pink transition-colors underline underline-offset-4">CREATE ACCOUNT</a>
          </p>
        </div>
      </div>
    </div>
  );
}
