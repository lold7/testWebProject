import { Link } from 'react-router-dom';
import { ArrowLeft, Download, Printer, Share2, Award } from 'lucide-react';

export default function Receipt() {
  return (
    <div className="max-w-2xl mx-auto space-y-8 py-8">
      <div className="flex items-center justify-between">
        <Link to="/order-confirmed" className="inline-flex items-center gap-2 text-text-muted hover:text-neon-cyan pixel-text text-xs transition-colors">
          <ArrowLeft className="w-4 h-4" /> BACK
        </Link>
        <div className="flex gap-4">
          <button className="p-2 text-text-muted hover:text-neon-cyan transition-colors" title="Download PDF">
            <Download className="w-5 h-5" />
          </button>
          <button className="p-2 text-text-muted hover:text-neon-pink transition-colors" title="Print Receipt">
            <Printer className="w-5 h-5" />
          </button>
          <button className="p-2 text-text-muted hover:text-neon-green transition-colors" title="Share">
            <Share2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="bg-bg-panel border-4 border-neon-green p-8 md:p-12 relative overflow-hidden rounded-xl shadow-[0_0_30px_rgba(57,255,20,0.1)]">
        {/* Receipt Header */}
        <div className="text-center space-y-4 border-b-2 border-dashed border-border-subtle pb-8 mb-8">
          <h1 className="pixel-text text-3xl text-neon-green mb-2">MAGIC LIB</h1>
          <p className="font-mono text-sm text-text-muted">
            123 Pixel Avenue, Sector 7G<br />
            Neo Tokyo, Earth 2049<br />
            TEL: 555-0199
          </p>
          <div className="pt-4 flex flex-col items-center gap-2">
            <div className="bg-neon-green/20 text-neon-green px-4 py-2 rounded-full flex items-center gap-2 border border-neon-green/50">
              <Award className="w-5 h-5" />
              <span className="font-bold tracking-widest">+100 EXP EARNED</span>
            </div>
            <h2 className="pixel-text text-xl text-text-primary mt-4">MISSION ACCOMPLISHED</h2>
          </div>
        </div>

        {/* Receipt Details */}
        <div className="space-y-6 font-mono text-sm">
          <div className="flex justify-between text-text-muted">
            <span>DATE: 2024-10-27</span>
            <span>TIME: 14:32:05</span>
          </div>
          <div className="flex justify-between text-text-muted">
            <span>ORDER ID: #ML-9942-X7</span>
            <span>TERMINAL: 04</span>
          </div>
          <div className="flex justify-between text-text-muted">
            <span>PLAYER: Player One</span>
            <span>CLASS: Mage</span>
          </div>

          {/* Items */}
          <div className="pt-6 border-t-2 border-dashed border-border-subtle space-y-4">
            <div className="flex justify-between text-text-muted font-bold mb-2">
              <span>ITEM</span>
              <span>PRICE</span>
            </div>
            {[
              { id: 1, title: "Ready Player One", qty: 1, price: "15.99" },
              { id: 2, title: "Neuromancer", qty: 2, price: "25.00" },
            ].map((item) => (
              <div key={item.id} className="flex justify-between items-start">
                <div>
                  <span className="text-text-primary">{item.title}</span>
                  <div className="text-text-muted text-xs mt-1">{item.qty} @ ${(Number(item.price)/item.qty).toFixed(2)}</div>
                </div>
                <span className="text-neon-green">${item.price}</span>
              </div>
            ))}
          </div>

          {/* Totals */}
          <div className="pt-6 border-t-2 border-dashed border-border-subtle space-y-2">
            <div className="flex justify-between text-text-muted">
              <span>SUBTOTAL</span>
              <span>$40.99</span>
            </div>
            <div className="flex justify-between text-text-muted">
              <span>SHIPPING</span>
              <span>$5.00</span>
            </div>
            <div className="flex justify-between text-text-muted">
              <span>TAX (8.5%)</span>
              <span>$3.68</span>
            </div>
            <div className="flex justify-between text-lg pt-4">
              <span className="pixel-text text-neon-cyan">TOTAL</span>
              <span className="text-neon-cyan font-bold">$49.67</span>
            </div>
          </div>
          
          {/* Payment Info */}
          <div className="pt-6 border-t-2 border-dashed border-border-subtle space-y-2 text-text-muted">
            <div className="flex justify-between">
              <span>PAYMENT METHOD</span>
              <span>CREDIT CARD</span>
            </div>
            <div className="flex justify-between">
              <span>CARD NUMBER</span>
              <span>**** **** **** 4242</span>
            </div>
            <div className="flex justify-between">
              <span>AUTH CODE</span>
              <span>098765</span>
            </div>
          </div>

          {/* Footer */}
          <div className="pt-12 text-center space-y-4">
            <p className="pixel-text text-xs text-text-muted">THANK YOU FOR PLAYING</p>
            <div className="flex justify-center">
              {/* Barcode placeholder */}
              <div className="h-12 w-48 bg-text-primary/20 flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 flex">
                  {[...Array(40)].map((_, i) => (
                    <div key={i} className="h-full bg-text-primary" style={{ width: `${Math.random() * 4 + 1}px`, marginRight: `${Math.random() * 3}px` }} />
                  ))}
                </div>
              </div>
            </div>
            <p className="text-xs text-text-muted">Keep this receipt for your records.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
