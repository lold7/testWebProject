import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Package, Users, Settings, BarChart2, Edit, Trash2, Plus, Search } from 'lucide-react';

export default function AdminInventory() {
  const [activeTab, setActiveTab] = useState('inventory');

  return (
    <div className="flex flex-col md:flex-row gap-8 min-h-[70vh]">
      {/* Admin Sidebar */}
      <aside className="w-full md:w-64 space-y-2">
        <div className="p-4 border-2 border-neon-pink bg-neon-pink/10 rounded-lg mb-6">
          <p className="pixel-text text-sm text-neon-pink mb-1">SYSTEM ADMIN</p>
          <p className="font-mono text-xs text-text-muted">ACCESS LEVEL: OMEGA</p>
        </div>
        
        <nav className="space-y-2">
          {[
            { id: 'dashboard', icon: BarChart2, label: 'DASHBOARD' },
            { id: 'inventory', icon: Package, label: 'INVENTORY' },
            { id: 'users', icon: Users, label: 'PLAYERS' },
            { id: 'settings', icon: Settings, label: 'SETTINGS' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-mono transition-colors rounded-lg border-2 ${
                activeTab === item.id 
                  ? 'border-neon-pink bg-neon-pink/10 text-neon-pink' 
                  : 'border-transparent text-text-muted hover:border-border-subtle hover:text-text-primary'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <div className="flex-1 space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-6 border-b border-border-subtle">
          <h1 className="pixel-text text-2xl text-text-primary">INVENTORY MANAGEMENT</h1>
          <button className="pixel-border-pink bg-neon-pink text-bg-dark px-4 py-2 pixel-text text-[10px] hover:bg-bg-dark hover:text-neon-pink transition-colors flex items-center gap-2">
            <Plus className="w-4 h-4" /> ADD ARTIFACT
          </button>
        </div>

        <div className="flex items-center gap-4 bg-bg-panel p-4 rounded-lg border border-border-subtle">
          <div className="relative flex-1">
            <input 
              type="text" 
              placeholder="SEARCH_BY_ID_OR_NAME..." 
              className="w-full bg-bg-dark border border-border-subtle pl-10 pr-4 py-2 font-mono text-sm focus:outline-none focus:border-neon-pink text-text-primary rounded"
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
          </div>
          <select className="bg-bg-dark border border-border-subtle text-text-muted text-sm font-mono py-2 px-4 rounded focus:outline-none focus:border-neon-pink">
            <option>ALL CATEGORIES</option>
            <option>CYBERPUNK</option>
            <option>SCI-FI</option>
          </select>
        </div>

        <div className="bg-bg-panel border border-border-subtle rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b-2 border-neon-pink bg-neon-pink/5">
                  <th className="p-4 font-mono text-xs text-neon-pink tracking-wider">ID</th>
                  <th className="p-4 font-mono text-xs text-neon-pink tracking-wider">ARTIFACT NAME</th>
                  <th className="p-4 font-mono text-xs text-neon-pink tracking-wider">STOCK</th>
                  <th className="p-4 font-mono text-xs text-neon-pink tracking-wider">PRICE</th>
                  <th className="p-4 font-mono text-xs text-neon-pink tracking-wider">STATUS</th>
                  <th className="p-4 font-mono text-xs text-neon-pink tracking-wider text-right">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="font-mono text-sm divide-y divide-border-subtle">
                {[
                  { id: "ART-001", name: "Ready Player One", stock: 42, price: "15.99", status: "ACTIVE" },
                  { id: "ART-002", name: "Neuromancer", stock: 12, price: "12.50", status: "LOW STOCK" },
                  { id: "ART-003", name: "Snow Crash", stock: 0, price: "14.20", status: "OUT OF STOCK" },
                  { id: "ART-004", name: "The Matrix Comics", stock: 8, price: "24.99", status: "LOW STOCK" },
                  { id: "ART-005", name: "Do Androids Dream?", stock: 156, price: "11.99", status: "ACTIVE" },
                ].map((item) => (
                  <tr key={item.id} className="hover:bg-bg-dark/50 transition-colors">
                    <td className="p-4 text-text-muted">{item.id}</td>
                    <td className="p-4 text-text-primary font-sans font-bold">{item.name}</td>
                    <td className="p-4">
                      <span className={`${
                        item.stock === 0 ? 'text-red-500' : 
                        item.stock < 20 ? 'text-neon-yellow' : 'text-neon-green'
                      }`}>
                        {item.stock}
                      </span>
                    </td>
                    <td className="p-4 text-text-muted">${item.price}</td>
                    <td className="p-4">
                      <span className={`px-2 py-1 text-[10px] rounded border ${
                        item.status === 'ACTIVE' ? 'bg-neon-green/10 text-neon-green border-neon-green/30' :
                        item.status === 'LOW STOCK' ? 'bg-neon-yellow/10 text-neon-yellow border-neon-yellow/30' :
                        'bg-red-500/10 text-red-500 border-red-500/30'
                      }`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex justify-end gap-2">
                        <button className="p-2 text-text-muted hover:text-neon-cyan bg-bg-dark rounded border border-border-subtle hover:border-neon-cyan transition-colors">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-text-muted hover:text-red-500 bg-bg-dark rounded border border-border-subtle hover:border-red-500 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-4 border-t border-border-subtle flex justify-between items-center text-sm font-mono text-text-muted">
            <span>SHOWING 1-5 OF 124 ARTIFACTS</span>
            <div className="flex gap-2">
              <button className="px-3 py-1 border border-border-subtle rounded hover:text-neon-pink hover:border-neon-pink transition-colors">PREV</button>
              <button className="px-3 py-1 border border-border-subtle rounded hover:text-neon-pink hover:border-neon-pink transition-colors">NEXT</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
