import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Trash2, ArrowRight, Shield, Zap } from 'lucide-react';

export default function Cart() {
  const [items, setItems] = useState([
    { id: 1, title: "Ready Player One", author: "Ernest Cline", price: 15.99, qty: 1, img: "https://picsum.photos/seed/book1/200/300" },
    { id: 2, title: "Neuromancer", author: "William Gibson", price: 25.00, qty: 2, img: "https://picsum.photos/seed/book2/200/300" },
  ]);

  const updateQty = (id: number, delta: number) => {
    setItems(items.map(item => {
      if (item.id === id) {
        return { ...item, qty: Math.max(1, item.qty + delta) };
      }
      return item;
    }));
  };

  const removeItem = (id: number) => {
    setItems(items.filter(item => item.id !== id));
  };

  const subtotal = items.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const shipping = 5.00;
  const tax = subtotal * 0.085;
  const total = subtotal + shipping + tax;

  return (
    <div className="space-y-8">
      <h1 className="pixel-text text-3xl md:text-4xl text-neon-green mb-8">CART CONTENTS</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-6">
          {items.length === 0 ? (
            <div className="bg-bg-panel border-2 border-dashed border-border-subtle p-12 text-center rounded-xl space-y-4">
              <p className="pixel-text text-text-muted">INVENTORY EMPTY</p>
              <Link to="/quests" className="inline-block text-neon-cyan hover:text-neon-pink transition-colors underline font-mono">
                RETURN TO QUEST BOARD
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {items.map((item) => (
                <div key={item.id} className="flex flex-col sm:flex-row gap-4 bg-bg-panel border border-border-subtle p-4 rounded-xl relative group">
                  <div className="w-24 h-36 shrink-0 rounded overflow-hidden border border-border-subtle">
                    <img src={item.img} alt={item.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  
                  <div className="flex-1 flex flex-col justify-between">
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <h3 className="font-bold text-lg text-text-primary group-hover:text-neon-cyan transition-colors">{item.title}</h3>
                        <p className="text-sm text-text-muted font-mono">{item.author}</p>
                      </div>
                      <button 
                        onClick={() => removeItem(item.id)}
                        className="p-2 text-text-muted hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                    
                    <div className="flex justify-between items-end mt-4">
                      <div className="flex items-center border border-border-subtle rounded bg-bg-dark">
                        <button 
                          onClick={() => updateQty(item.id, -1)}
                          className="px-3 py-1 text-text-muted hover:text-neon-cyan transition-colors"
                        >
                          -
                        </button>
                        <span className="w-8 text-center font-mono text-sm">{item.qty}</span>
                        <button 
                          onClick={() => updateQty(item.id, 1)}
                          className="px-3 py-1 text-text-muted hover:text-neon-cyan transition-colors"
                        >
                          +
                        </button>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-text-muted font-mono mb-1">${item.price.toFixed(2)} / ea</div>
                        <div className="pixel-text text-neon-green">${(item.price * item.qty).toFixed(2)}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Order Summary */}
        <div className="space-y-6">
          <div className="bg-bg-panel border-4 border-neon-cyan p-6 rounded-xl space-y-6 sticky top-24">
            <h2 className="pixel-text text-xl text-neon-cyan border-b border-border-subtle pb-4">
              ORDER DATA
            </h2>
            
            <div className="space-y-4 font-mono text-sm">
              <div className="flex justify-between text-text-muted">
                <span>SUBTOTAL</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-text-muted">
                <span>SHIPPING</span>
                <span>${shipping.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-text-muted">
                <span>TAX (EST)</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              
              <div className="pt-4 border-t border-border-subtle flex justify-between items-end">
                <span className="pixel-text text-text-primary text-xs">TOTAL</span>
                <span className="font-mono font-bold text-2xl text-neon-cyan">${total.toFixed(2)}</span>
              </div>
            </div>

            <div className="pt-4 space-y-4">
              <Link 
                to="/checkout" 
                className={`w-full pixel-border-cyan bg-neon-cyan text-bg-dark px-4 py-4 pixel-text text-xs hover:bg-bg-dark hover:text-neon-cyan transition-all flex items-center justify-center gap-2 ${items.length === 0 ? 'opacity-50 pointer-events-none' : ''}`}
              >
                PROCEED TO NEXT LEVEL <ArrowRight className="w-4 h-4" />
              </Link>
              
              <div className="flex items-center justify-center gap-2 text-xs text-text-muted font-mono">
                <Shield className="w-4 h-4 text-neon-green" /> SECURE CONNECTION
              </div>
            </div>
          </div>
          
          <div className="bg-bg-panel border border-border-subtle p-4 rounded-xl flex items-start gap-4">
            <div className="p-2 bg-neon-yellow/10 rounded-lg text-neon-yellow shrink-0">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <h4 className="pixel-text text-[10px] text-neon-yellow mb-1">FAST TRAVEL ENABLED</h4>
              <p className="text-xs text-text-muted font-mono">Orders placed before 14:00 server time ship same day.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
