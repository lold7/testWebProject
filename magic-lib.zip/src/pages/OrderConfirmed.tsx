import { Link } from 'react-router-dom';
import { CheckCircle, ArrowRight, Package, MapPin, CreditCard } from 'lucide-react';

export default function OrderConfirmed() {
  return (
    <div className="max-w-3xl mx-auto space-y-12 py-12">
      <div className="flex flex-col items-center text-center space-y-6">
        <div className="w-24 h-24 rounded-full bg-neon-green/20 flex items-center justify-center text-neon-green mb-4 animate-pulse">
          <CheckCircle className="w-12 h-12" />
        </div>
        <h1 className="pixel-text text-4xl md:text-5xl text-neon-green drop-shadow-[0_0_10px_rgba(57,255,20,0.5)]">
          LEVEL CLEARED!
        </h1>
        <p className="text-xl text-text-muted">
          Your order has been successfully processed.
        </p>
        <div className="bg-bg-panel border-2 border-neon-cyan px-8 py-4 rounded-xl inline-block">
          <p className="pixel-text text-sm text-neon-cyan mb-2">ORDER ID</p>
          <p className="font-mono text-2xl tracking-widest text-text-primary">#ML-9942-X7</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-bg-panel border border-border-subtle p-6 rounded-xl space-y-6">
          <h2 className="pixel-text text-lg text-neon-pink flex items-center gap-3 border-b border-border-subtle pb-4">
            <Package className="w-5 h-5" /> DELIVERY STATUS
          </h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center text-sm">
              <span className="text-text-muted">Estimated Arrival</span>
              <span className="font-mono text-neon-green">3-5 Business Days</span>
            </div>
            <div className="w-full bg-bg-dark h-2 rounded-full overflow-hidden">
              <div className="bg-neon-green w-1/3 h-full rounded-full" />
            </div>
            <p className="text-xs text-text-muted text-center font-mono">
              PREPARING FOR TELEPORTATION...
            </p>
          </div>
        </div>

        <div className="bg-bg-panel border border-border-subtle p-6 rounded-xl space-y-6">
          <h2 className="pixel-text text-lg text-neon-yellow flex items-center gap-3 border-b border-border-subtle pb-4">
            <MapPin className="w-5 h-5" /> SHIPPING TO
          </h2>
          <div className="space-y-2 text-sm text-text-muted font-mono">
            <p className="text-text-primary">Player One</p>
            <p>123 Pixel Avenue</p>
            <p>Sector 7G, Neo Tokyo</p>
            <p>Earth, 2049</p>
          </div>
        </div>
      </div>

      <div className="bg-bg-panel border border-border-subtle p-6 rounded-xl space-y-6">
        <h2 className="pixel-text text-lg text-neon-cyan flex items-center gap-3 border-b border-border-subtle pb-4">
          <CreditCard className="w-5 h-5" /> ORDER SUMMARY
        </h2>
        
        <div className="space-y-4">
          {[
            { id: 1, title: "Ready Player One", qty: 1, price: "15.99" },
            { id: 2, title: "Neuromancer", qty: 2, price: "25.00" },
          ].map((item) => (
            <div key={item.id} className="flex justify-between items-center text-sm border-b border-border-subtle/50 pb-4">
              <div className="flex items-center gap-4">
                <span className="text-text-muted font-mono">{item.qty}x</span>
                <span className="text-text-primary">{item.title}</span>
              </div>
              <span className="font-mono text-neon-green">${item.price}</span>
            </div>
          ))}
          
          <div className="pt-4 space-y-2 text-sm">
            <div className="flex justify-between text-text-muted">
              <span>Subtotal</span>
              <span className="font-mono">$40.99</span>
            </div>
            <div className="flex justify-between text-text-muted">
              <span>Shipping</span>
              <span className="font-mono">$5.00</span>
            </div>
            <div className="flex justify-between text-text-muted">
              <span>Tax</span>
              <span className="font-mono">$3.68</span>
            </div>
            <div className="flex justify-between text-lg pt-4 border-t border-border-subtle">
              <span className="pixel-text text-neon-cyan">TOTAL</span>
              <span className="font-mono text-neon-cyan font-bold">$49.67</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-8">
        <Link to="/receipt" className="text-text-muted hover:text-neon-pink pixel-text text-xs transition-colors underline underline-offset-4">
          VIEW FULL RECEIPT
        </Link>
        <Link to="/quests" className="pixel-border-green bg-neon-green text-bg-dark px-8 py-4 pixel-text text-sm hover:bg-neon-cyan hover:text-bg-dark hover:pixel-border-cyan transition-all flex items-center gap-2">
          CONTINUE QUEST <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}
