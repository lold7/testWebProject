import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ShoppingCart, Star, Shield, Zap, Book } from 'lucide-react';

export default function ProductDetail() {
  const [qty, setQty] = useState(1);
  const [activeTab, setActiveTab] = useState('description');

  return (
    <div className="space-y-12">
      <Link to="/quests" className="inline-flex items-center gap-2 text-text-muted hover:text-neon-cyan pixel-text text-xs transition-colors">
        <ArrowLeft className="w-4 h-4" /> BACK TO QUEST BOARD
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24">
        {/* Image Gallery */}
        <div className="space-y-6">
          <div className="aspect-[3/4] rounded-2xl border-4 border-neon-green bg-bg-panel overflow-hidden relative group">
            <img 
              src="https://picsum.photos/seed/book1/800/1200" 
              alt="Ready Player One" 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-4 right-4 bg-bg-dark/80 backdrop-blur px-3 py-1.5 rounded pixel-text text-xs text-neon-yellow border border-neon-yellow">
              LEGENDARY
            </div>
          </div>
          <div className="grid grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <button key={i} className={`aspect-square rounded border-2 overflow-hidden ${i === 1 ? 'border-neon-cyan' : 'border-border-subtle hover:border-neon-pink'}`}>
                <img src={`https://picsum.photos/seed/book${i}/200/200`} alt={`Thumbnail ${i}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </button>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-8">
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-neon-pink pixel-text text-[10px]">
              <Star className="w-3 h-3 fill-neon-pink" />
              <Star className="w-3 h-3 fill-neon-pink" />
              <Star className="w-3 h-3 fill-neon-pink" />
              <Star className="w-3 h-3 fill-neon-pink" />
              <Star className="w-3 h-3 fill-neon-pink" />
              <span className="ml-2 text-text-muted">(4.9/5 from 1,337 reviews)</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-text-primary leading-tight">
              Ready Player One
            </h1>
            <p className="text-xl text-neon-cyan font-mono">Ernest Cline</p>
          </div>

          <div className="flex items-end gap-4 border-b border-border-subtle pb-8">
            <span className="pixel-text text-4xl text-neon-green">$15.99</span>
            <span className="text-text-muted line-through mb-1">$24.99</span>
            <span className="bg-neon-pink/20 text-neon-pink px-2 py-1 rounded text-xs font-bold mb-1 border border-neon-pink/50">
              -36%
            </span>
          </div>

          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="flex items-center border-2 border-border-subtle rounded-lg overflow-hidden bg-bg-panel">
                <button 
                  onClick={() => setQty(Math.max(1, qty - 1))}
                  className="px-4 py-3 text-text-muted hover:text-neon-cyan hover:bg-bg-dark transition-colors"
                >
                  -
                </button>
                <span className="w-12 text-center font-mono text-lg">{qty}</span>
                <button 
                  onClick={() => setQty(qty + 1)}
                  className="px-4 py-3 text-text-muted hover:text-neon-cyan hover:bg-bg-dark transition-colors"
                >
                  +
                </button>
              </div>
              <button className="flex-1 pixel-border-green bg-neon-green text-bg-dark px-8 py-4 pixel-text text-sm hover:bg-neon-cyan hover:text-bg-dark hover:pixel-border-cyan transition-all flex items-center justify-center gap-3">
                <ShoppingCart className="w-5 h-5" /> ADD TO INVENTORY
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="flex items-center gap-3 text-sm text-text-muted bg-bg-panel p-3 rounded border border-border-subtle">
                <Shield className="w-5 h-5 text-neon-green" />
                <span>Secure Checkout</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-text-muted bg-bg-panel p-3 rounded border border-border-subtle">
                <Zap className="w-5 h-5 text-neon-yellow" />
                <span>Instant Download</span>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="pt-8 space-y-6">
            <div className="flex gap-8 border-b border-border-subtle">
              {['description', 'details', 'reviews'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`pb-4 text-sm font-bold uppercase tracking-wider transition-colors relative ${
                    activeTab === tab ? 'text-neon-cyan' : 'text-text-muted hover:text-text-primary'
                  }`}
                >
                  {tab}
                  {activeTab === tab && (
                    <span className="absolute bottom-0 left-0 w-full h-1 bg-neon-cyan rounded-t" />
                  )}
                </button>
              ))}
            </div>
            
            <div className="text-text-muted leading-relaxed space-y-4">
              {activeTab === 'description' && (
                <>
                  <p>
                    In the year 2045, reality is an ugly place. The only time teenage Wade Watts really feels alive is when he's jacked into the OASIS, a vast virtual world where most of humanity spends their days.
                  </p>
                  <p>
                    When the eccentric creator of the OASIS dies, he leaves behind a series of fiendish puzzles, based on his obsession with the pop culture of decades past. Whoever is first to solve them will inherit his vast fortune—and control of the OASIS itself.
                  </p>
                </>
              )}
              {activeTab === 'details' && (
                <ul className="space-y-2 font-mono text-sm">
                  <li><span className="text-text-primary">Publisher:</span> Crown Publishing Group</li>
                  <li><span className="text-text-primary">Publication date:</span> August 16, 2011</li>
                  <li><span className="text-text-primary">Pages:</span> 374</li>
                  <li><span className="text-text-primary">ISBN:</span> 978-0307887436</li>
                </ul>
              )}
              {activeTab === 'reviews' && (
                <div className="space-y-6">
                  <div className="border-b border-border-subtle pb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex text-neon-pink"><Star className="w-3 h-3 fill-neon-pink" /><Star className="w-3 h-3 fill-neon-pink" /><Star className="w-3 h-3 fill-neon-pink" /><Star className="w-3 h-3 fill-neon-pink" /><Star className="w-3 h-3 fill-neon-pink" /></div>
                      <span className="font-bold text-text-primary text-sm">Parzival</span>
                    </div>
                    <p className="text-sm">"A masterpiece. The references are perfectly executed and the pacing is relentless."</p>
                  </div>
                  <div className="border-b border-border-subtle pb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex text-neon-pink"><Star className="w-3 h-3 fill-neon-pink" /><Star className="w-3 h-3 fill-neon-pink" /><Star className="w-3 h-3 fill-neon-pink" /><Star className="w-3 h-3 fill-neon-pink" /><Star className="w-3 h-3 text-border-subtle" /></div>
                      <span className="font-bold text-text-primary text-sm">Art3mis</span>
                    </div>
                    <p className="text-sm">"Great world-building, though some of the 80s trivia gets a bit dense. Still a must-read."</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Similar Artifacts */}
      <section className="pt-16 border-t border-border-subtle space-y-8">
        <h2 className="pixel-text text-2xl text-neon-pink flex items-center gap-3">
          <Book className="w-6 h-6" /> SIMILAR ARTIFACTS
        </h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { id: 2, title: "Neuromancer", author: "William Gibson", price: "12.50", img: "https://picsum.photos/seed/book2/400/600" },
            { id: 3, title: "Snow Crash", author: "Neal Stephenson", price: "14.20", img: "https://picsum.photos/seed/book3/400/600" },
            { id: 4, title: "The Matrix Comics", author: "Wachowskis", price: "24.99", img: "https://picsum.photos/seed/book4/400/600" },
            { id: 5, title: "Do Androids Dream?", author: "Philip K. Dick", price: "11.99", img: "https://picsum.photos/seed/book5/400/600" },
          ].map((book) => (
            <Link key={book.id} to={`/product`} className="group flex flex-col gap-4 p-4 border-2 border-border-subtle hover:border-neon-pink bg-bg-panel transition-colors rounded-lg">
              <div className="aspect-[2/3] overflow-hidden rounded border border-border-subtle relative">
                <img src={book.img} alt={book.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
              </div>
              <div className="space-y-2 flex-1 flex flex-col">
                <h3 className="font-bold text-lg text-text-primary line-clamp-1 group-hover:text-neon-pink transition-colors">{book.title}</h3>
                <p className="text-sm text-text-muted">{book.author}</p>
                <div className="mt-auto pt-4 flex items-center justify-between">
                  <span className="pixel-text text-sm text-neon-green">${book.price}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
