import { Link } from 'react-router-dom';
import { ArrowRight, MapPin, CreditCard, Package, ShieldCheck } from 'lucide-react';

export default function Checkout() {
  return (
    <div className="space-y-8">
      <h1 className="pixel-text text-3xl md:text-4xl text-neon-yellow mb-8">CHECKOUT</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Forms */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-bg-panel border-4 border-neon-cyan p-6 md:p-8 rounded-xl space-y-6">
            <h2 className="pixel-text text-xl text-neon-cyan flex items-center gap-3 border-b border-border-subtle pb-4">
              <MapPin className="w-6 h-6" /> SHIPPING COORDINATES
            </h2>
            
            <form className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-sm">
              <div className="space-y-2 md:col-span-2">
                <label className="text-text-muted">FULL NAME</label>
                <input type="text" defaultValue="Player One" className="w-full bg-bg-dark border border-border-subtle p-3 focus:outline-none focus:border-neon-cyan text-text-primary" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <label className="text-text-muted">STREET ADDRESS</label>
                <input type="text" defaultValue="123 Pixel Avenue" className="w-full bg-bg-dark border border-border-subtle p-3 focus:outline-none focus:border-neon-cyan text-text-primary" />
              </div>
              <div className="space-y-2">
                <label className="text-text-muted">CITY / SECTOR</label>
                <input type="text" defaultValue="Neo Tokyo" className="w-full bg-bg-dark border border-border-subtle p-3 focus:outline-none focus:border-neon-cyan text-text-primary" />
              </div>
              <div className="space-y-2">
                <label className="text-text-muted">PLANET / REGION</label>
                <input type="text" defaultValue="Earth" className="w-full bg-bg-dark border border-border-subtle p-3 focus:outline-none focus:border-neon-cyan text-text-primary" />
              </div>
              <div className="space-y-2">
                <label className="text-text-muted">ZIP / POSTAL CODE</label>
                <input type="text" defaultValue="2049" className="w-full bg-bg-dark border border-border-subtle p-3 focus:outline-none focus:border-neon-cyan text-text-primary" />
              </div>
              <div className="space-y-2">
                <label className="text-text-muted">COMM LINK (PHONE)</label>
                <input type="tel" defaultValue="555-0199" className="w-full bg-bg-dark border border-border-subtle p-3 focus:outline-none focus:border-neon-cyan text-text-primary" />
              </div>
            </form>
          </div>

          <div className="bg-bg-panel border-4 border-neon-pink p-6 md:p-8 rounded-xl space-y-6">
            <h2 className="pixel-text text-xl text-neon-pink flex items-center gap-3 border-b border-border-subtle pb-4">
              <CreditCard className="w-6 h-6" /> PAYMENT METHOD
            </h2>
            
            <div className="space-y-4">
              <label className="flex items-center gap-4 p-4 border border-neon-pink bg-neon-pink/5 rounded cursor-pointer">
                <input type="radio" name="payment" defaultChecked className="accent-neon-pink" />
                <div className="flex-1 font-mono text-sm">
                  <span className="text-text-primary block mb-1">CREDIT / DEBIT CARD</span>
                  <span className="text-text-muted text-xs">Secure encrypted transaction</span>
                </div>
                <CreditCard className="w-6 h-6 text-neon-pink" />
              </label>
              
              <label className="flex items-center gap-4 p-4 border border-border-subtle hover:border-neon-pink transition-colors rounded cursor-pointer">
                <input type="radio" name="payment" className="accent-neon-pink" />
                <div className="flex-1 font-mono text-sm">
                  <span className="text-text-primary block mb-1">CRYPTO WALLET</span>
                  <span className="text-text-muted text-xs">Pay with BTC, ETH, SOL</span>
                </div>
                <div className="w-6 h-6 rounded-full bg-neon-yellow/20 flex items-center justify-center text-neon-yellow font-bold text-xs">₿</div>
              </label>
            </div>

            <form className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-sm pt-4 border-t border-border-subtle">
              <div className="space-y-2 md:col-span-2">
                <label className="text-text-muted">CARD NUMBER</label>
                <input type="text" placeholder="**** **** **** ****" className="w-full bg-bg-dark border border-border-subtle p-3 focus:outline-none focus:border-neon-pink text-text-primary" />
              </div>
              <div className="space-y-2">
                <label className="text-text-muted">EXPIRATION (MM/YY)</label>
                <input type="text" placeholder="MM/YY" className="w-full bg-bg-dark border border-border-subtle p-3 focus:outline-none focus:border-neon-pink text-text-primary" />
              </div>
              <div className="space-y-2">
                <label className="text-text-muted">CVC</label>
                <input type="text" placeholder="***" className="w-full bg-bg-dark border border-border-subtle p-3 focus:outline-none focus:border-neon-pink text-text-primary" />
              </div>
            </form>
          </div>
        </div>

        {/* Order Summary */}
        <div className="space-y-6">
          <div className="bg-bg-panel border-4 border-neon-green p-6 rounded-xl space-y-6 sticky top-24">
            <h2 className="pixel-text text-xl text-neon-green border-b border-border-subtle pb-4 flex items-center gap-3">
              <Package className="w-6 h-6" /> INVENTORY
            </h2>
            
            <div className="space-y-4 font-mono text-sm">
              {[
                { id: 1, title: "Ready Player One", qty: 1, price: 15.99 },
                { id: 2, title: "Neuromancer", qty: 2, price: 25.00 },
              ].map((item) => (
                <div key={item.id} className="flex justify-between items-start border-b border-border-subtle/50 pb-4">
                  <div>
                    <span className="text-text-primary">{item.title}</span>
                    <div className="text-text-muted text-xs mt-1">QTY: {item.qty}</div>
                  </div>
                  <span className="text-neon-green">${(item.price * item.qty).toFixed(2)}</span>
                </div>
              ))}
              
              <div className="pt-2 space-y-2">
                <div className="flex justify-between text-text-muted">
                  <span>SUBTOTAL</span>
                  <span>$65.99</span>
                </div>
                <div className="flex justify-between text-text-muted">
                  <span>SHIPPING</span>
                  <span>$5.00</span>
                </div>
                <div className="flex justify-between text-text-muted">
                  <span>TAX</span>
                  <span>$3.68</span>
                </div>
              </div>
              
              <div className="pt-4 border-t border-border-subtle flex justify-between items-end">
                <span className="pixel-text text-text-primary text-xs">TOTAL</span>
                <span className="font-mono font-bold text-2xl text-neon-green">$74.67</span>
              </div>
            </div>

            <div className="pt-4 space-y-4">
              <Link 
                to="/order-confirmed" 
                className="w-full pixel-border-green bg-neon-green text-bg-dark px-4 py-4 pixel-text text-xs hover:bg-bg-dark hover:text-neon-green transition-all flex items-center justify-center gap-2"
              >
                PRESS START TO PAY <ArrowRight className="w-4 h-4" />
              </Link>
              
              <div className="flex items-center justify-center gap-2 text-xs text-text-muted font-mono">
                <ShieldCheck className="w-4 h-4 text-neon-cyan" /> 256-BIT ENCRYPTION ACTIVE
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
