import { useState } from 'react';
import { Link } from 'react-router-dom';
import { User, Package, Settings, Star, Award, Shield, Zap, ChevronRight } from 'lucide-react';

export default function Profile() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="flex flex-col md:flex-row gap-8 min-h-[70vh]">
      {/* Sidebar */}
      <aside className="w-full md:w-64 space-y-6">
        <div className="bg-bg-panel border-4 border-neon-cyan p-6 rounded-xl text-center space-y-4 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-neon-cyan/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2" />
          
          <div className="w-24 h-24 mx-auto bg-bg-dark border-2 border-neon-cyan rounded-full overflow-hidden relative z-10">
            <img src="https://api.dicebear.com/7.x/pixel-art/svg?seed=PlayerOne" alt="Avatar" className="w-full h-full object-cover" />
          </div>
          
          <div className="relative z-10">
            <h2 className="pixel-text text-lg text-neon-cyan mb-1">PLAYER ONE</h2>
            <p className="font-mono text-xs text-text-muted">LVL 42 MAGE</p>
          </div>
          
          <div className="pt-4 border-t border-border-subtle relative z-10">
            <div className="flex justify-between text-[10px] font-mono mb-1">
              <span className="text-neon-yellow">EXP</span>
              <span className="text-text-muted">8450 / 10000</span>
            </div>
            <div className="w-full bg-bg-dark h-2 rounded-full overflow-hidden border border-border-subtle">
              <div className="bg-neon-yellow w-[84.5%] h-full rounded-full" />
            </div>
          </div>
        </div>
        
        <nav className="space-y-2">
          {[
            { id: 'overview', icon: User, label: 'OVERVIEW' },
            { id: 'orders', icon: Package, label: 'QUEST HISTORY' },
            { id: 'wishlist', icon: Star, label: 'WISHLIST' },
            { id: 'settings', icon: Settings, label: 'SETTINGS' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-mono transition-colors rounded-lg border-2 ${
                activeTab === item.id 
                  ? 'border-neon-cyan bg-neon-cyan/10 text-neon-cyan' 
                  : 'border-transparent text-text-muted hover:border-border-subtle hover:text-text-primary'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <div className="flex-1 space-y-8">
        <h1 className="pixel-text text-3xl text-text-primary border-b-2 border-neon-cyan pb-4">
          {activeTab === 'overview' && 'PLAYER STATS'}
          {activeTab === 'orders' && 'QUEST HISTORY'}
          {activeTab === 'wishlist' && 'WISHLIST'}
          {activeTab === 'settings' && 'SETTINGS'}
        </h1>

        {activeTab === 'overview' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="bg-bg-panel border border-border-subtle p-6 rounded-xl flex flex-col items-center text-center gap-2 hover:border-neon-green transition-colors">
                <Award className="w-8 h-8 text-neon-green mb-2" />
                <span className="pixel-text text-2xl text-text-primary">12</span>
                <span className="font-mono text-xs text-text-muted">QUESTS COMPLETED</span>
              </div>
              <div className="bg-bg-panel border border-border-subtle p-6 rounded-xl flex flex-col items-center text-center gap-2 hover:border-neon-pink transition-colors">
                <Shield className="w-8 h-8 text-neon-pink mb-2" />
                <span className="pixel-text text-2xl text-text-primary">5</span>
                <span className="font-mono text-xs text-text-muted">ACHIEVEMENTS</span>
              </div>
              <div className="bg-bg-panel border border-border-subtle p-6 rounded-xl flex flex-col items-center text-center gap-2 hover:border-neon-yellow transition-colors">
                <Zap className="w-8 h-8 text-neon-yellow mb-2" />
                <span className="pixel-text text-2xl text-text-primary">8450</span>
                <span className="font-mono text-xs text-text-muted">TOTAL EXP</span>
              </div>
            </div>

            <div className="bg-bg-panel border border-border-subtle rounded-xl overflow-hidden">
              <div className="p-6 border-b border-border-subtle flex justify-between items-center">
                <h3 className="pixel-text text-lg text-neon-cyan">RECENT ACTIVITY</h3>
                <button onClick={() => setActiveTab('orders')} className="text-xs font-mono text-text-muted hover:text-neon-cyan transition-colors flex items-center gap-1">
                  VIEW ALL <ChevronRight className="w-4 h-4" />
                </button>
              </div>
              <div className="divide-y divide-border-subtle">
                {[
                  { id: "#ML-9942-X7", date: "2024-10-27", status: "DELIVERED", items: 3, total: "$49.67" },
                  { id: "#ML-8831-Y2", date: "2024-09-15", status: "DELIVERED", items: 1, total: "$24.99" },
                  { id: "#ML-7720-Z9", date: "2024-08-02", status: "DELIVERED", items: 5, total: "$112.50" },
                ].map((order) => (
                  <div key={order.id} className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-bg-dark/50 transition-colors">
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <span className="font-mono font-bold text-text-primary">{order.id}</span>
                        <span className="px-2 py-0.5 text-[10px] rounded border bg-neon-green/10 text-neon-green border-neon-green/30 font-mono">
                          {order.status}
                        </span>
                      </div>
                      <p className="text-xs text-text-muted font-mono">{order.date} • {order.items} ARTIFACTS</p>
                    </div>
                    <div className="flex items-center gap-6">
                      <span className="font-mono text-neon-cyan">{order.total}</span>
                      <Link to="/receipt" className="px-4 py-2 bg-bg-dark border border-border-subtle rounded text-xs font-mono text-text-muted hover:text-neon-cyan hover:border-neon-cyan transition-colors">
                        VIEW RECEIPT
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="space-y-6">
            <div className="flex gap-4 mb-6">
              <button className="px-4 py-2 border-b-2 border-neon-cyan text-neon-cyan font-mono text-sm">ALL QUESTS</button>
              <button className="px-4 py-2 border-b-2 border-transparent text-text-muted hover:text-text-primary font-mono text-sm transition-colors">ACTIVE</button>
              <button className="px-4 py-2 border-b-2 border-transparent text-text-muted hover:text-text-primary font-mono text-sm transition-colors">COMPLETED</button>
            </div>
            
            {[
              { id: "#ML-9942-X7", date: "2024-10-27", status: "DELIVERED", items: 3, total: "$49.67" },
              { id: "#ML-8831-Y2", date: "2024-09-15", status: "DELIVERED", items: 1, total: "$24.99" },
              { id: "#ML-7720-Z9", date: "2024-08-02", status: "DELIVERED", items: 5, total: "$112.50" },
              { id: "#ML-6619-A1", date: "2024-05-20", status: "DELIVERED", items: 2, total: "$35.00" },
            ].map((order) => (
              <div key={order.id} className="bg-bg-panel border border-border-subtle rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-neon-cyan transition-colors">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="font-mono font-bold text-lg text-text-primary">{order.id}</span>
                    <span className="px-2 py-1 text-[10px] rounded border bg-neon-green/10 text-neon-green border-neon-green/30 font-mono">
                      {order.status}
                    </span>
                  </div>
                  <p className="text-sm text-text-muted font-mono mb-2">DATE: {order.date}</p>
                  <p className="text-sm text-text-muted font-mono">{order.items} ARTIFACTS</p>
                </div>
                <div className="flex flex-col items-end gap-4">
                  <span className="font-mono text-xl text-neon-cyan font-bold">{order.total}</span>
                  <div className="flex gap-2">
                    <button className="px-4 py-2 bg-bg-dark border border-border-subtle rounded text-xs font-mono text-text-muted hover:text-neon-pink hover:border-neon-pink transition-colors">
                      TRACK
                    </button>
                    <Link to="/receipt" className="px-4 py-2 bg-bg-dark border border-border-subtle rounded text-xs font-mono text-text-muted hover:text-neon-cyan hover:border-neon-cyan transition-colors">
                      RECEIPT
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
