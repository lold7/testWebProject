import { Link } from 'react-router-dom';
import { ArrowRight, Star, Zap, Shield, Book } from 'lucide-react';

export default function Home() {
  return (
    <div className="space-y-16 md:space-y-24">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-2xl border-4 border-neon-green bg-bg-panel p-8 md:p-16 lg:p-24 flex flex-col items-center text-center">
        <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at center, var(--color-neon-green) 0%, transparent 70%)' }} />
        <div className="relative z-10 max-w-3xl mx-auto space-y-8">
          <h1 className="pixel-text text-4xl md:text-6xl lg:text-7xl text-neon-green leading-tight drop-shadow-[0_0_15px_rgba(57,255,20,0.5)]">
            UNLOCK THE MAGIC
          </h1>
          <p className="text-lg md:text-xl text-text-muted max-w-2xl mx-auto">
            Your portal to infinite worlds. Level up your mind with our curated collection of magical artifacts (books).
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Link to="/quests" className="pixel-border-green bg-neon-green text-bg-dark px-8 py-4 pixel-text text-sm hover:bg-neon-cyan hover:text-bg-dark hover:pixel-border-cyan transition-all w-full sm:w-auto flex items-center justify-center gap-2">
              START QUEST <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="space-y-8">
        <div className="flex items-center justify-between border-b-2 border-border-subtle pb-4">
          <h2 className="pixel-text text-2xl text-neon-cyan flex items-center gap-3">
            <Zap className="w-6 h-6 text-neon-yellow" /> NEW ARRIVALS
          </h2>
          <Link to="/quests" className="text-neon-cyan hover:text-neon-pink pixel-text text-xs flex items-center gap-2">
            VIEW ALL <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { id: 1, title: "Ready Player One", author: "Ernest Cline", price: "15.99", img: "https://picsum.photos/seed/book1/400/600" },
            { id: 2, title: "Neuromancer", author: "William Gibson", price: "12.50", img: "https://picsum.photos/seed/book2/400/600" },
            { id: 3, title: "Snow Crash", author: "Neal Stephenson", price: "14.20", img: "https://picsum.photos/seed/book3/400/600" },
            { id: 4, title: "The Matrix Comics", author: "Wachowskis", price: "24.99", img: "https://picsum.photos/seed/book4/400/600" },
          ].map((book) => (
            <Link key={book.id} to={`/product`} className="group flex flex-col gap-4 p-4 border-2 border-border-subtle hover:border-neon-cyan bg-bg-panel transition-colors rounded-lg">
              <div className="aspect-[2/3] overflow-hidden rounded border border-border-subtle relative">
                <img src={book.img} alt={book.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
                <div className="absolute top-2 right-2 bg-bg-dark/80 backdrop-blur px-2 py-1 rounded pixel-text text-[10px] text-neon-yellow border border-neon-yellow">
                  NEW
                </div>
              </div>
              <div className="space-y-2 flex-1 flex flex-col">
                <h3 className="font-bold text-lg text-text-primary line-clamp-1 group-hover:text-neon-cyan transition-colors">{book.title}</h3>
                <p className="text-sm text-text-muted">{book.author}</p>
                <div className="mt-auto pt-4 flex items-center justify-between">
                  <span className="pixel-text text-sm text-neon-green">${book.price}</span>
                  <button className="p-2 bg-bg-dark border border-neon-green text-neon-green hover:bg-neon-green hover:text-bg-dark transition-colors rounded">
                    <Book className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Why Shop With Us */}
      <section className="border-4 border-neon-pink bg-bg-panel p-8 md:p-12 rounded-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-neon-pink/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        
        <h2 className="pixel-text text-2xl md:text-3xl text-neon-pink mb-8 text-center">
          WHY SHOP WITH MAGIC LIB?
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
          <div className="flex flex-col items-center text-center gap-4 p-6 border border-border-subtle rounded-xl bg-bg-dark/50 hover:border-neon-pink transition-colors">
            <div className="w-16 h-16 rounded-full bg-neon-pink/20 flex items-center justify-center text-neon-pink mb-2">
              <Star className="w-8 h-8" />
            </div>
            <h3 className="pixel-text text-sm text-text-primary">CURATED ARTIFACTS</h3>
            <p className="text-sm text-text-muted">Only the highest quality tomes make it into our inventory.</p>
          </div>
          
          <div className="flex flex-col items-center text-center gap-4 p-6 border border-border-subtle rounded-xl bg-bg-dark/50 hover:border-neon-cyan transition-colors">
            <div className="w-16 h-16 rounded-full bg-neon-cyan/20 flex items-center justify-center text-neon-cyan mb-2">
              <Zap className="w-8 h-8" />
            </div>
            <h3 className="pixel-text text-sm text-text-primary">FAST TRAVEL DELIVERY</h3>
            <p className="text-sm text-text-muted">Teleportation-speed shipping straight to your coordinates.</p>
          </div>
          
          <div className="flex flex-col items-center text-center gap-4 p-6 border border-border-subtle rounded-xl bg-bg-dark/50 hover:border-neon-green transition-colors">
            <div className="w-16 h-16 rounded-full bg-neon-green/20 flex items-center justify-center text-neon-green mb-2">
              <Shield className="w-8 h-8" />
            </div>
            <h3 className="pixel-text text-sm text-text-primary">SECURE TRANSACTIONS</h3>
            <p className="text-sm text-text-muted">Your gold and data are protected by top-tier encryption magic.</p>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="bg-neon-green text-bg-dark p-8 md:p-16 rounded-2xl flex flex-col items-center text-center gap-6">
        <h2 className="pixel-text text-2xl md:text-3xl">JOIN THE GUILD</h2>
        <p className="max-w-md font-medium">Subscribe to our transmission network for exclusive drops, secret levels, and bonus EXP.</p>
        <form className="flex flex-col sm:flex-row gap-4 w-full max-w-lg mt-4">
          <input 
            type="email" 
            placeholder="ENTER_EMAIL_ADDRESS..." 
            className="flex-1 bg-bg-dark text-neon-green border-2 border-bg-dark p-4 font-mono focus:outline-none focus:border-neon-pink placeholder:text-neon-green/50"
          />
          <button type="submit" className="pixel-border bg-bg-dark text-neon-green px-8 py-4 pixel-text text-sm hover:bg-neon-pink hover:text-bg-dark transition-colors">
            SUBSCRIBE
          </button>
        </form>
      </section>
    </div>
  );
}
